/** Automatically generated file. DO NOT MODIFY */
package kp.magicspoiler;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}