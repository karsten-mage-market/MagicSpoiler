package kp.magicspoiler;

import java.net.URL;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class ProgramActivity extends Activity {
	TextView textView;
	ImageView listView;
	int height;

	void setImage() {
		final Result res = (Result) listView.getTag();
		setTitle(res.title + " spoiled, viewing #" + (1 + res.index));
		new AsyncTask<Void, Void, Bitmap>() {
			@Override
			protected Bitmap doInBackground(Void... params) {
				try {
					return BitmapFactory.decodeStream(new URL(
							res.imgs[res.index]).openStream());
				} catch (Exception e) {
					return null;
				}
			}

			@Override
			protected void onPostExecute(Bitmap bmp) {
				if (bmp != null) {
					listView.setImageBitmap(bmp);
				}
			}
		}.execute();
	}

	void move(int dx) {
		Result res = (Result) listView.getTag();
		if (res == null) {
			return;
		}
		res.index += dx;
		if (res.index >= res.imgs.length) {
			res.index = 0;
		}
		if (res.index < 0) {
			res.index = res.imgs.length - 1;
		}
		setImage();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_program);

		textView = (TextView) findViewById(R.id.textView);
		listView = (ImageView) findViewById(R.id.imageView);
		height = textView.getHeight();

		new RetrieveMagicTask() {
			@Override
			protected void onPostExecute(Result r) {
				if (r.error) {
					textView.setText(r.exception.getMessage());
					textView.setHeight(height);
				} else {
					textView.setText("");
					textView.setHeight(0);
					listView.setTag(r);
					setImage();
				}
			}
		}.execute();

		listView.setOnTouchListener(new OnSwipeListener(getApplicationContext()) {
			@Override
			public void onSwipeLeft() {
				move(1);
			}

			@Override
			public void onSwipeRight() {
				move(-1);
			}

			@Override
			public void onSwipeTop() {
				move(1);
			}

			@Override
			public void onSwipeBottom() {
				move(-1);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}

/*
 * Supplier<Res> orNull(final Supplier<Res> f) { return () -> { try { return
 * f(); } catch (Exception e) { return null; } }; }
 * 
 * <Res> async(final Supplier<Res> f, final Consumer<Res> g) { new
 * AsyncTask<Void, Void, Res>() {
 * 
 * @Override protected Res doInBackground(Void... params) { return f(); }
 * 
 * @Override protected void onPostExecute(Res x) { g(res); } }.execute(); }
 */